var covidDetails = (function(){
    function init(){
        var stateName = "AP";
        var data = getData(stateName);
        constructDetail(data);
    }
    function getData(stateName){
        var respData = {};
		jQuery.ajax({
			url : "https://data.covid19india.org/v4/min/timeseries.min.json",
			async : false,
			success : function(data){
				respData =  stateName ? data[stateName] : data;
			}
		});
		return respData;
    }
    function constructDetail(stateData){
        stateData = stateData.dates;
        var timeKeys = Object.keys(stateData);
        jQuery("#detail-holder").html("");
        var detailStr = "";
        for(var i=0;i<timeKeys.length;i++){
            var dataObj = stateData[timeKeys[i]];
            var totalObj = dataObj.total || {};
            var deltaObj = dataObj.delta || {};
            var delta7Obj = dataObj.delta7 || {};
            var classStr = (i%2 == 0) ? 'odd' : '';
                detailStr += '<div class="tr '+ classStr +'">';
                detailStr += ' <div class="td date-col">'+timeKeys[i]+'</div>';
                detailStr += '<div class="td conf-col">'+(totalObj.confirmed || 0)+'</div>'+
                '<div class="td recov-col">'+(totalObj.recovered || 0)+'</div>'+
                '<div class="td deceas-col">'+(totalObj.deceased || 0)+'</div>';

                detailStr += '<div class="td delta-col"><div>';
                if(jQuery.isEmptyObject(deltaObj)){
                    detailStr += "-"; 
                }else{
                    detailStr += constructDelta(deltaObj);
                }
                detailStr += '</div></div>';

                detailStr += '<div class="td delta7-col"><div>';
                if(jQuery.isEmptyObject(delta7Obj)){
                    detailStr += "-"; 
                }else{
                    detailStr += constructDelta(delta7Obj);
                }
                detailStr += '</div></div></div>';
        }
        jQuery("#detail-holder").html(detailStr);
    }
    function constructDelta(deltaObj){
        var detlaStr = "";
        var deltaKeys = Object.keys(deltaObj);
        for(var i=0;i<deltaKeys.length;i++){
            detlaStr += '<div class="stat"><label class="text-muted stat-name">'+deltaKeys[i]+'</label>&nbsp;<span>:</span>&nbsp;<span class="stat-count">'+deltaObj[deltaKeys[i]]+'</span></div>';
        }
        return detlaStr;
    }
    return {
        init : init
    }
}());