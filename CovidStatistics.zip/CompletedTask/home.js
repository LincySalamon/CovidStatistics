var covid = (function(){
	var statesDataG = {}; // Store all the states data
	var statesArrayG = []; // Store all the states names(key)
	var timeDataG = {}; //Store all the time based state data
	var dateStateArrayG = []; // Store time based state names(key)
	var currentlyloadedStatesDataG = [];
	function init(){
		statesDataG = getData();
		statesArrayG = Object.keys(statesDataG);
		constructCardList(statesArrayG);

		//Event binding for next previous icons and filters
		filterEvents(statesArrayG);

		//Getting time based data
		timeDataG = getTimeData();
		dateStateArrayG = Object.keys(timeDataG);
	};
	function getData(){
		var respData = {};
		jQuery.ajax({
			url : "https:/data.covid19india.org/v4/min/data.min.json",
			async : false,
			success : function(data){
				statesDataG = respData = data;
			}
		});
		return respData;
	};
	function getTimeData(){
		var respData = {};
		jQuery.ajax({
			url : "https://data.covid19india.org/v4/min/timeseries.min.json",
			async : false,
			success : function(data){
				timeDataG = respData = data;
			}
		});
		return respData;
	};
	function constructCardList(states, filterData){
		var data = filterData || statesDataG; //data - States data with district (API 1)
		var length = states.length;
			jQuery("#card_holder").html("");
			
			for (var i = 0; i < length; i++) {
				var state = states[i];
				var stateObj = data[state];
				var _districts = Object.keys(stateObj.districts || {});

				/*Single Card's skeleton - Starts*/
				var stateDetail = '<div class="card">'+
					'<div class="card-title">'+
						'<span class="mr10">'+state+'</span>';
						if(_districts.length){
							stateDetail += '<input data-stateid="'+state+'" id="'+state+'_district" class="district-select"/>';
						}
					stateDetail += '</div>'+
					'<div class="card-list" data-stateid="'+state+'" id="'+state+'-card-list">';
					stateDetail += '</div></div>';
					/*Single Card's skeleton - Ends*/

					jQuery("#card_holder").append(stateDetail);
					constructCard(state, stateObj);
					if(_districts.length){
						constructDistSelect2(state, stateObj, _districts);
					}
			}
			//No records image
			if(jQuery("#card_holder").html() == ""){
				jQuery("#card_holder").html('<img src="norecords.jpeg" width="100%" height="88%">');
				return;
			}
			eventBinding();
			currentlyloadedStatesDataG = states.slice(0);// To avoid reference
	};
	function constructCard(state, stateObj){
		var typeArray = ["total", "delta", "delta7"];

			//If District change happens, it should replace the existing HTML
			jQuery("#"+state+"-card-list").empty();
			var affected_percent = (stateObj["total"].confirmed / statesDataG[state]["meta"]["population"])*100;
			var vaccinated_percent = (stateObj["total"].vaccinated1 / statesDataG[state]["meta"]["population"])*100;
			for (var j = 0; j < typeArray.length; j++) {
				/* 
				  stateObj = {"total" : {confirmed : 0}, "delta" : {}, "delta7" : {}}
				  statisticObj = {confirmed : 0}
				  statistics = ["confirmed"]
				*/
	    		var statisticObj = stateObj[typeArray[j]] || {}; 
	    		var statistics = Object.keys(statisticObj);
	    		var statisticsKeysLength = statistics.length;

	    		var statDetail = "", arrowRight = '', arrowLeft='';
	    		if(statisticsKeysLength){
	    			var slideClass = ' slider ';
	    			if(j == 0){
	    				arrowRight = '<span class="arrow-span right-span" title=" Show Next"><i class="arrow right"></i></span>';
	    			}else{
	    				if(j == 1){
	        				arrowRight = '<span class="arrow-span right-span" title=" Show Next"><i class="arrow right"></i></span>';
	        			}
	    				arrowLeft  = '<span class="arrow-span left-span" title=" Show Previous"><i class="arrow left"></i></span>';
	    				slideClass += 'hide'
	    			}
	    			
	    			statDetail = '<div class="'+slideClass+'">';
	    			statDetail += arrowLeft;
	        		statDetail += '<div class="type">'+ typeArray[j] +'</div>';

					statDetail += constructDelta(statisticObj, affected_percent, vaccinated_percent);
	        		
	        		statDetail += arrowRight;
	        		statDetail += '</div>';
	        	}
	        	jQuery("#"+state+"-card-list").append(statDetail);
	    	}
	};
	function constructDistSelect2(state, stateObj, _districts){
		var distArr = [];
		var districtCount = _districts.length;
        	for(let x=0; x<districtCount;x++){
        		var distJson = {};
        		distJson = {"id" : _districts[x], "text": _districts[x], distObj : stateObj.districts[_districts[x]], state_name: state };
        		distArr.push(distJson);
        	}
        	jQuery("#"+state+"_district").select2({
        		placeholder: "--Select a District--",
        		allowClear: true,
        		data : distArr
        	}).on('change',function(e){
        		var stateName = "";
        		var distStatData  = {};
        		var selectData =jQuery(this).select2('data');
        		if(selectData){
        			stateName = selectData.state_name;
        			distStatData  = selectData.distObj;
        		}else{
        			stateName = jQuery(this).attr("data-stateid");
					distStatData = statesDataG[stateName];
        		}
				//distStatData - District's data to construct card
				//stateName - Card id - '{stateName}-card-list'
        		constructCard(stateName, distStatData);
        	});
	}
	function eventBinding(){
		jQuery(".card-list").on("click", function(e){
			var stateId = jQuery(this).attr("data-stateid");
				localStorage.setItem("state", stateId);
				window.location.href = "file:///D:/offlineTask/CovidTask/details.html";
		});
		jQuery(".right-span").on("click",function(e){
			e.stopImmediatePropagation()
			var parent = jQuery(this).closest(".slider");
				parent.fadeOut();
				parent.next().fadeIn();
		});
		jQuery(".left-span").on("click", function(e){
			e.stopImmediatePropagation()
			var parent = jQuery(this).closest(".slider");
				parent.fadeOut();
				parent.prev().fadeIn();
		});
		
	}
	function filterEvents(states){
		stateFilterEvent(states);
		datePickerEvent();
		sortByEvent();
	}
	function stateFilterEvent(states){
		var stateArr = [];
		for(let y =0; y<states.length;y++){
			var stateJSON = {};
			stateJSON = {"id":states[y],"text":states[y]};
			stateArr.push(stateJSON);
		}
		jQuery('#state-filter').select2({
			placeholder : "--Select State--",
			allowClear : true,
			data : stateArr
		}).on('change',function(e){
			var select_state_name = []; //To reuse the code for single and multiple states, making array variable (Used in constructCardList)
			var selectedState = jQuery(this).select2('data');
			var selectedDate = jQuery('#date-filter').val();
			if(selectedDate){
				dateAndStateFilter();
			}
			else{
				if(selectedState){
					select_state_name.push(selectedState.id);
				}	
				else{
					select_state_name = states; // states - array of state names
				}
				constructCardList(select_state_name);
			}
			jQuery("#sortby_element").select2("val", "");
		});
	}
	/*
		Function used in Home and Details page
		stateName - will be available only in details page initialization (data from localstorage)
		selectedDate - will be available only in details page initialization (data from localstorage)
	*/
	function datePickerEvent(stateName,selectedDate){ 
		if(selectedDate){
			//Setting selected date , which is coming from localstorage
			jQuery('#date-filter').val(selectedDate);
		}
		jQuery('#date-filter').on('change',function(e){
			dateAndStateFilter(stateName);
			jQuery("#sortby_element").select2("val", "");
		});
	}
	function dateAndStateFilter(stateName){ //stateName will be passsing only for details page
		var selectedState; //Declaring variable
		var stateFilterValue = jQuery('#state-filter').val() || stateName;
			if(stateFilterValue){
				selectedState = [];
				selectedState.push(stateFilterValue);
			}
			var selectedDate = jQuery('#date-filter').val();
			localStorage.setItem("filteredDate",selectedDate);
			if(selectedDate){
				var dateFilterJSON = {};
				/*
					selectedState  - If any of the state is selected in filter dropdown
					if 'selectedState' is undefined (not selected), it will consider below variable
					dateStateArrayG - Array of All the state names available in time based API
				*/
				var Date_states_arr = selectedState || dateStateArrayG; //Array of state names
				for(let l=0;l<Date_states_arr.length;l++){
					var state_name = Date_states_arr[l];
					
					/*
					Below - Getting State based data from timebased API - 
					{'dates' : {'20-10-2021' : {'total' : {}}}
					*/
					var datesObj = timeDataG[state_name]; 
					var stateDataOnSelectedDate = datesObj.dates && datesObj.dates[selectedDate]; //Checking selected date is available in state's data
					if(stateDataOnSelectedDate){
						dateFilterJSON[state_name] = stateDataOnSelectedDate;	
					}						
				}	

				/*
					dateFilterJSON  = 
					{"AN" : { 'total' : {}, "delta":{}}}
				*/
				var filteredStateNames = Object.keys(dateFilterJSON); //Array of state names

				/*if check will go for details page alone*/
				if(stateName){
					var dateObject = {};
					if(jQuery.isEmptyObject(dateFilterJSON[stateName])){
						dateObject = dateFilterJSON;
					}else{
						dateObject[stateName] = {};
						dateObject[stateName][selectedDate] = dateFilterJSON[stateName];
					}
					/*
						dateObject -> {
							"AN" : {
								"2023-12-01" : {'total':{'confirmed' :0}}
							}
						}
					*/
					covidDetails.constructDetail(dateObject);
				}else{
					constructCardList(filteredStateNames,dateFilterJSON);
				}
			}
			else{
				if(stateName){ //Details Page
					covidDetails.constructDetail();
				}else{ //Home page
					constructCardList(statesArrayG);
				}
			}
	}
	function sortByEvent(){
		jQuery("#sortby_element").select2({
			"placeholder":"--Select--", 
			"allowClear":true
		}).on("change", function(){
			sortBy(jQuery(this).val(), jQuery("#sort_order").find("i.active").attr("data-sort"));
		});
		jQuery("#sort_order").on("click", function(){
			jQuery(this).find("i").toggleClass("active inactive");
			var sort_order = jQuery(this).find("i.active").attr("data-sort");
			if(jQuery("#sortby_element").val()){
				sortBy(jQuery("#sortby_element").val(), sort_order == "asc");
			}
		});
	}
	function constructDelta(deltaObj, affected_percent, vaccinated_percent){
        var detlaStr = "";
        var deltaKeys = Object.keys(deltaObj);
        for(var i=0;i<deltaKeys.length;i++){
			var percentStr = (affected_percent && deltaKeys[i]=="confirmed") ? '( ' +Math.round(affected_percent)+'% )' : "";
			var vaccinatedStr = (vaccinated_percent && deltaKeys[i] == "vaccinated1") ? '( ' +Math.round(vaccinated_percent)+'% )' : "";
            detlaStr += '<div class="stat"><label class="text-muted stat-name">'+deltaKeys[i]+'</label>&nbsp;<span>:</span>&nbsp;<span class="stat-count">'+deltaObj[deltaKeys[i]]+percentStr+vaccinatedStr+'</span></div>';
        }
        return detlaStr;
    }
	function sortBy(selectedSort, isAsc){
		var sortedStateList = currentlyloadedStatesDataG;
		if(selectedSort == "confirmed"){
			sortedStateList.sort(function(a, b){
				return isAsc ? (statesDataG[a].total.confirmed - statesDataG[b].total.confirmed) : (statesDataG[b].total.confirmed - statesDataG[a].total.confirmed)
			});
		}else if(selectedSort == "affected"){
			sortedStateList.sort(function(a, b){
				var percentage1 = (statesDataG[a].total.confirmed / statesDataG[a].meta.population)*100;
				var percentage2 = (statesDataG[b].total.confirmed / statesDataG[b].meta.population)*100;
				return isAsc ? (percentage1 - percentage2) : (percentage2 - percentage1);
			});
		}else{
			sortedStateList.sort(function(a, b){
				var percentage1 = (statesDataG[a].total.vaccinated1 / statesDataG[a].meta.population)*100;
				var percentage2 = (statesDataG[b].total.vaccinated1 / statesDataG[b].meta.population)*100;
				return isAsc ? (percentage1 - percentage2) : (percentage2 - percentage1);
			});
		}
		constructCardList(sortedStateList);
	}
	return {
		init : init,
		getTimeData : getTimeData,
		constructDelta : constructDelta,
		datePickerEvent : datePickerEvent
	};
}());

var covidDetails = (function(){
	var stateName = localStorage.getItem("state") || "AP";
	var detailfilterDate = localStorage.getItem("filteredDate");
	var stateAndDateDataG = {};
    function init(){
		jQuery("#state-name").html(stateName);
		stateAndDateDataG[stateName] = covid.getTimeData()[stateName].dates;
			if(detailfilterDate){
				var DetailstateDataJSON ={};
				var DetailstateData = stateAndDateDataG[stateName][detailfilterDate];
				DetailstateDataJSON[stateName] ={};
				DetailstateDataJSON[stateName][detailfilterDate] = DetailstateData;
				constructDetail(DetailstateDataJSON);
			}
			else{
				constructDetail();
			}
			covid.datePickerEvent(stateName,detailfilterDate);

    }
    function constructDetail(stateData){
        stateData = stateData || stateAndDateDataG;
        jQuery("#detail-holder").html("");
		var dateObj = stateData[stateName];
		if(jQuery.isEmptyObject(dateObj)){
			jQuery("#detail-holder").html('<img src="norecords.jpeg" width="100%" height="88%">');
			return;
		}
        var detailStr = "";
		var timeKeys = Object.keys(dateObj);
        for(var i=0;i<timeKeys.length;i++){
            var dataObj = dateObj[timeKeys[i]];
            var totalObj = dataObj.total || {};
            var deltaObj = dataObj.delta || {};
            var delta7Obj = dataObj.delta7 || {};
            var classStr = (i%2 == 0) ? 'odd' : '';
                detailStr += '<div class="tr '+ classStr +'">';
                detailStr += ' <div class="td date-col">'+timeKeys[i]+'</div>';
                detailStr += '<div class="td conf-col">'+(totalObj.confirmed || 0)+'</div>'+
                '<div class="td recov-col">'+(totalObj.recovered || 0)+'</div>'+
                '<div class="td deceas-col">'+(totalObj.deceased || 0)+'</div>';

                detailStr += '<div class="td delta-col"><div>';
                if(jQuery.isEmptyObject(deltaObj)){
                    detailStr += "-"; 
                }else{
                    detailStr += covid.constructDelta(deltaObj);
                }
                detailStr += '</div></div>';

                detailStr += '<div class="td delta7-col"><div>';
                if(jQuery.isEmptyObject(delta7Obj)){
                    detailStr += "-"; 
                }else{
                    detailStr += covid.constructDelta(delta7Obj);
                }
                detailStr += '</div></div></div>';
        }
        jQuery("#detail-holder").html(detailStr);
    }
    return {
        init : init,
		constructDetail : constructDetail
    }
}());